package controller;


/**
 * Launch the simulation
 *
 * @author EMAKO TIENTCHEU
 * @version 2017
 */
public class Launcher {

	/**
	 * Launch the simulation
	 * @param args not used
	 */
	public static void main(String[] args) {
		new Simulation().run();
	}

}
