package model;
/**
 * An item in the city.
 * 
 * @author EMAKO TIENTCHEU
 * @version 2011.07.31
 */

public interface Item
{
    public Location getLocation();
}
